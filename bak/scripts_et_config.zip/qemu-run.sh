#! /bin/bash

# Fixer les variables avec les chemins de vos fichiers
HDA="-hda /tmp/pnl-tp.img"
HDB="-hdb ${HOME}/myHome.img"
FLAGS="--enable-kvm "

exec qemu-system-x86_64 ${FLAGS} \
     ${HDA} ${HDB} \
     -net user -net nic \
     -boot c -m 2G
